#!/usr/bin/python2	


import commands	

x = commands.getstatusoutput("ssh -X  bhagyashree@192.168.42.151 notepad")

raw_input() 

			