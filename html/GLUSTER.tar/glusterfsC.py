#!/usr/bin/python2	

import commands,os	

os.system("mkdir /media/whiteSauce")	

os.system("mount -o rw 192.168.42.151:/whiteSauce /media/whiteSauce")	

raw_input()	

			